package crime.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import crime.model.*;


public class EditDAO {
	private static Connection con; 
	  private static PreparedStatement stmt;
	  
	public static void getConnection()
	  {	 	
		  String JdbcURL = "jdbc:mysql://localhost:3306/crimedb?" + "autoReconnect=true&useSSL=false";
	      String Username = "root";
	      String password = "";
	       con = null;      
	      try 
	      {
	    	 Class.forName("com.mysql.jdbc.Driver");   // Driver should be registered
	    	 // con=DriverManager.getConnection( "jdbc:mysql://localhost:3306/test1","root","");  
	         con = DriverManager.getConnection(JdbcURL, Username, password);
	         
	      } 
	      catch (Exception e) 
	      {
	         e.printStackTrace();
	      }
		   
		 
	  }
	  public static void closeConnection()
	  {
		  try{
			  if(con.isClosed()==false)
		          con.close();   // closing the connection
		  }
		  catch(Exception e)
		  { e.printStackTrace();	 }
	  }  
	  
	  public static Boolean edit(Registermodel edt)
	  {  
		  try
		  {
		  getConnection();
		  int nor=0;
	      stmt=con.prepareStatement("select count(*) from registration where name=? and email=? and adds=? and ph_no=? and pass=?"); 
	      stmt.setString(1, edt.getName());
		  stmt.setString(2, edt.getEmail());
		  stmt.setString(3, edt.getAdds());
		  stmt.setString(4, edt.getPh_no());
		  stmt.setString(5, edt.getPass());
	      nor=stmt.executeUpdate();
		     closeConnection();	 
		    if(nor>0)
		    {
		    	return true;
		    }
		    return false;
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return false; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return false; }  	  
	  }
}
